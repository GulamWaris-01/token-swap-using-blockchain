import theme from './theme';
import user from './user';
import tokens from './tokens';

export default {
  theme,
  user,
  tokens
};