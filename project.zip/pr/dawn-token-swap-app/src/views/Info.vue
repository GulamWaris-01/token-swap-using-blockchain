<template>
  <div class="container mx-auto px-4">This is the info page.</div>
</template>
